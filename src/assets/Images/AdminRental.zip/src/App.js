import React from 'react';
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import Users from './components/Users';
import Inventory from './components/Inventory';
import Rentals from './components/Rentals';
import Payments from './components/Payments';
import Feedback from './components/Feedback';
import AddInventory from './components/AddInventory';
// import CategorizeInventory from './components/CategorizeInventory';
// import UserPayments from './components/UserPayments';
// import InventoryAvailability from './components/InventoryAvailability';
import Sidebar from './components/Sidebar';
import Login from './components/Login';
import Signup from './components/Signup';
import OtpVerification from './components/OtpVerification';
import PrivateRoute from './components/PrivateRoute';
import EditItem from './components/EditItem';
import './styles/index.css';
import { isAuthenticated } from './auth';

function AppContent() {
  const location = useLocation();
  const hideSidebarRoutes = ['/login', '/signup', '/verify-otp'];

  return (
    <div className="App">
      {isAuthenticated() && !hideSidebarRoutes.includes(location.pathname) && <Sidebar />}
      <div className="content">
        <Routes>
          <Route path="/signup" element={<Signup />} />
          <Route path="/verify-otp" element={<OtpVerification />} />
          <Route path="/login" element={<Login />} />

          <Route
            path="/"
            element={
              <PrivateRoute>
                <Dashboard />
              </PrivateRoute>
            }
          />
          <Route
            path="/users"
            element={
              <PrivateRoute>
                <Users />
              </PrivateRoute>
            }
          />
          <Route
            path="/inventory"
            element={
              <PrivateRoute>
                <Inventory />
              </PrivateRoute>
            }
          />
          <Route
            path="/rentals"
            element={
              <PrivateRoute>
                <Rentals />
              </PrivateRoute>
            }
          />
          <Route
            path="/payments"
            element={
              <PrivateRoute>
                <Payments />
              </PrivateRoute>
            }
          />
          <Route
            path="/feedback"
            element={
              <PrivateRoute>
                <Feedback />
              </PrivateRoute>
            }
          />
          <Route
            path="/add-inventory"
            element={
              <PrivateRoute>
                <AddInventory />
              </PrivateRoute>
            }
          />
          <Route
            path="/editItem/:id"
            element={
              <PrivateRoute>
                <EditItem />
              </PrivateRoute>
            }
          />
          {/* <Route
            path="/categorize-inventory"
            element={
              <PrivateRoute>
                <CategorizeInventory />
              </PrivateRoute>
            }
          />
          <Route
            path="/user-payments/:userId"
            element={
              <PrivateRoute>
                <UserPayments />
              </PrivateRoute>
            }
          />
          <Route
            path="/inventory-availability/:productId"
            element={
              <PrivateRoute>
                <InventoryAvailability />
              </PrivateRoute>
            }
          /> */}
        </Routes>
      </div>
    </div>
  );
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;
