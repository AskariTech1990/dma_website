// src/components/Dashboard.js
import React, { useEffect, useState } from 'react';

const Dashboard = () => {
    const [totalUsers, setTotalUsers] = useState(0);
    const [totalItems, setTotalItems] = useState(0);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch("https://2lkz6gq8-5001.inc1.devtunnels.ms/api/admin/totaluser");
                const data = await response.json();
                setTotalUsers(data);
                console.log("Data coming total revenue.....", data);
            } catch (error) {
                console.log("error coming here", error);
            }
        };

        const fetchTotalItems = async () => {
            try {
                const itemResponse = await fetch("https://2lkz6gq8-5001.inc1.devtunnels.ms/api/inventory/total-items");
                const itemData = await itemResponse.json();
                setTotalItems(itemData.totalCount);
                console.log("items coming", itemData);
            } catch (error) {
                console.log("error in item", error);
            }
        };

        fetchData();
        fetchTotalItems();
    }, []);

    return (
        <div className="dashboard p-4">
            <h1 className='text-3xl font-bold mb-5 text-left'>Dashboard</h1>
            <div className="stats grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="stat p-4 bg-white rounded-lg shadow-md font-bold text-center h-20">
                    Total Users: {totalUsers}
                </div>
                <div className="stat p-4 bg-white rounded-lg shadow-md font-bold text-center h-20">
                    Total rentals: 0
                </div>
                <div className="stat p-4 bg-white rounded-lg shadow-md font-bold text-center h-20">
                    Total items: {totalItems}
                </div>
                <div className="stat p-4 bg-white rounded-lg shadow-md font-bold text-center h-20">
                    Revenue: 0
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
