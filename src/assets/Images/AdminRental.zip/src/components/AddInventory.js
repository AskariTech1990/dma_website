import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Select from 'react-select';

const AddInventory = () => {
    const [itemName, setItemName] = useState('');
    const [category, setCategory] = useState('');
    const [description, setDescription] = useState('');
    const [rentalPrice, setRentalPrice] = useState('');
    const [duration, setDuration] = useState('');
    const [available, setAvailable] = useState('');
    const [maintenance, setMaintenance] = useState('');
    const [quantity, setQuantity] = useState(0);
    const [image, setImage] = useState(null);

    const navigate = useNavigate();

    const categories = [
        { value: 'Excavator', label: 'Excavator' },
        { value: 'Bulldozer', label: 'Bulldozer' },
        { value: 'Crane', label: 'Crane' },
        { value: 'Forklift', label: 'Forklift' },
        { value: 'Loader', label: 'Loader' },
        { value: 'Backhoe', label: 'Backhoe' },
        { value: 'Dump Truck', label: 'Dump Truck' },
    ];

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Create formData object
        const formData = new FormData();
        formData.append('name', itemName);
        formData.append('category', category);
        formData.append('description', description);
        formData.append('rentalPrice', rentalPrice);
        formData.append('duration', duration);
        formData.append('quantity', quantity);
        formData.append('available', available);
        formData.append('maintenance', maintenance);
        formData.append('image', image);

        try {
            // Make POST request using axios
            const response = await axios.post('https://2lkz6gq8-5001.inc1.devtunnels.ms/api/inventory/', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            console.log(response.data);
            navigate('/inventory');
        } catch (error) {
            console.error('Error adding inventory:', error);
        }
    };

    const handleImageChange = (e) => {
        setImage(e.target.files[0]); // Set the selected image file
    };

    const handleCategoryChange = (selectedOption) => {
        setCategory(selectedOption ? selectedOption.value : '');
    };

    return (
        <div className="add-inventory">
            <h1 className='font-bold text-2xl'>Add Product</h1>
            <form onSubmit={handleSubmit}>
                <label className='font-bold'>
                    Item Name:
                    <input type="text" value={itemName} onChange={(e) => setItemName(e.target.value)} required />
                </label>
                <label className='font-bold'>
                    Category:
                    <Select
                        options={categories}
                        onChange={handleCategoryChange}
                        onInputChange={(inputValue, actionMeta) => {
                            if (actionMeta.action === 'input-change' && !categories.find(cat => cat.value === inputValue)) {
                                setCategory(inputValue);
                            }
                        }}
                        isClearable
                        isSearchable
                        placeholder="Select or type a category"
                    />
                </label>
                <label className='font-bold'>
                    Description:
                    <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} />
                </label>
                <label className='font-bold'>
                    Rental Price:
                    <input type="text" value={rentalPrice} onChange={(e) => setRentalPrice(e.target.value)} />
                </label>
                <label className='font-bold'>
                    Duration:
                    <input type="text" value={duration} onChange={(e) => setDuration(e.target.value)} />
                </label>
                <label className='font-bold'>
                    Quantity:
                    <input type="number" value={quantity} onChange={(e) => setQuantity(e.target.value)} required />
                </label>
                <label className='font-bold'>
                    Available:
                    <select value={available} onChange={(e) => setAvailable(e.target.value === 'true')}>
                        <option value={true}>Yes</option>
                        <option value={false}>No</option>
                    </select>
                </label>
                <label className='font-bold'>
                    Maintenance:
                    <select value={maintenance} onChange={(e) => setMaintenance(e.target.value === 'true')}>
                        <option value={true}>Yes</option>
                        <option value={false}>No</option>
                    </select>
                </label>
                <label className='font-bold'>
                    Image:
                    <input type="file" onChange={handleImageChange} />
                </label>
                <div className='flex items-center justify-center'>
                    <button type="submit" className='bg-blue-400 px-6 py-2'>Add</button>
                </div>
            </form>
        </div>
    );
};

export default AddInventory;
