import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Rentals = () => {
  const [rentals, setRentals] = useState([]);
  const [loading, setLoading] = useState(true); // State to manage loading state

  useEffect(() => {
    axios.get('https://2lkz6gq8-5001.inc1.devtunnels.ms/api/admin/get-all-rentals')
      .then(response => {
        console.log('Rentals data:', response.data);
        setRentals(response.data.rentals || []); // Set rentals directly from response data
        setLoading(false); // Set loading to false once data is fetched
      })
      .catch(error => {
        console.error('Error fetching rentals:', error);
        setLoading(false); // Set loading to false on error as well
      });
  }, []);

  return (
    <div className="rentals">
      <h1 className="text-3xl font-bold mb-4">All Rentals</h1>
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
          <p className="ml-2">Loading...</p>
        </div>
      ) : (
        <table className="table-auto w-full border-collapse border border-green-800">
          <thead>
            <tr className="bg-customColor-circleColor">
              <th className="border border-green-600 px-4 py-2">Product Name</th>
              <th className="border border-green-600 px-4 py-2">Rental Date</th>
              <th className="border border-green-600 px-4 py-2">Return Date</th>
              <th className="border border-green-600 px-4 py-2">Status</th>
              <th className="border border-green-600 px-4 py-2">Terms Accepted</th>
              <th className="border border-green-600 px-4 py-2">User Name</th>
            </tr>
          </thead>
          <tbody>
            {rentals.map(rental => (
              <tr key={rental._id} className="bg-gray-100">
                <td className="border border-green-600 px-4 py-2 ">{rental.itemName}</td>
                <td className="border border-green-600 px-4 py-2">{new Date(rental.rentalDate).toLocaleDateString()}</td>
                <td className="border border-green-600 px-4 py-2">{new Date(rental.returnDate).toLocaleDateString()}</td>
                <td className="border border-green-600 px-4 py-2">{rental.status}</td>
                <td className="border border-green-600 px-4 py-2">{rental.termsAccepted ? 'Accepted' : 'Not Accepted'}</td>
                <td className="border border-green-600 px-4 py-2">{rental.userName}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Rentals;
