import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import RentalLogo from "../assets/Images/LogoRental.png";
import { removeToken } from '../auth';

const Sidebar = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        removeToken();
        navigate('/login');
    };

    return (
        <div className="sidebar items-center flex flex-col gap-2">
            {/* <h2 className='text-3xl font-bold'>DMA</h2> */}
            <img src={RentalLogo} alt="rentalLogo" />
            <div className='bg-white items-center justify-center flex text-black hover:bg-customColor-circleColor hover:text-white py-3 rounded w-full font-bold'>
                <Link to="/">Dashboard</Link>
            </div>
            <div className='bg-white items-center justify-center flex text-black hover:bg-customColor-circleColor hover:text-white py-3 rounded w-full font-bold'>
                <Link to="/users">Users</Link>
            </div>
            <div className='bg-white items-center justify-center flex text-black hover:bg-customColor-circleColor hover:text-white py-3 rounded w-full font-bold'>
                <Link to="/inventory">Inventory</Link>
            </div>
            <div className='bg-white items-center justify-center flex text-black hover:bg-customColor-circleColor hover:text-white py-3 rounded w-full font-bold'>
                <Link to="/add-inventory">Add Product</Link>
            </div>
            <div className='bg-white items-center justify-center flex text-black hover:bg-customColor-circleColor hover:text-white py-3 rounded w-full font-bold'>
                <Link to="/rentals">Rentals History</Link>
            </div>
            <div className='bg-white items-center justify-center flex text-black hover:bg-customColor-circleColor hover:text-white py-3 rounded w-full font-bold'>
                <Link to="/payments">Payments History</Link>
            </div>
            <div className='bg-white items-center justify-center flex text-black hover:bg-customColor-circleColor hover:text-white py-3 rounded w-full font-bold'>
                <Link to="/feedback">Feedback History</Link>
            </div>
            {/* <div className='bg-white items-center justify-center flex text-black hover:bg-customColor-circleColor hover:text-white py-3 rounded w-full font-bold'>
                <Link to="/categorize-inventory">Categorize Inventory</Link>
            </div> */}
            <div className='bg-white items-center justify-center flex text-black hover:bg-customColor-circleColor hover:text-white py-3 rounded w-full font-bold cursor-pointer' onClick={handleLogout}>
                <div>Logout</div>
            </div>
        </div>
    );
};

export default Sidebar;
